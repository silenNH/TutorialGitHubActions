exports.handler = function(event,context,callback){
    console.log('Lambda function successfully ceated uing aws cli');
    callback(null,"succcess");
};